//
//  Recipe.swift
//  Recipe App
//
//  Created by Rayan on 30/06/2024.
//

import Foundation

struct Recipe: Codable {
    
    var id: String?
    var type: String?
    var name: String?
    var image: Data?
    var description: String?
    var ingredients: String?
    var steps: String?
    
    init(type: String, name: String, image: Data, description: String, ingredients: String, steps: String) {
        self.id = generateID()
        self.type = type
        self.name = name
        self.image = image
        self.description = description
        self.ingredients = ingredients
        self.steps = steps
    }
    
    mutating func update(type: String, name: String, image: Data, description: String, ingredients: String, steps: String) {
        self.type = type
        self.name = name
        self.image = image
        self.description = description
        self.ingredients = ingredients
        self.steps = steps
    }
    
    func generateID() -> String {
        let letters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
        return String((0..<10).map{ _ in letters.randomElement()! })
    }
    
}
