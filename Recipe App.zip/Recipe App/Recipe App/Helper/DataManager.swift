//
//  DataManager.swift
//  Recipe App
//
//  Created by Rayan on 30/06/2024.
//

import Foundation
import UIKit

class DataManager {
    
    private let userDefaultsKey = "recipes"
    
    // MARK: - CRUD Operations
    
    func addRecipe(_ recipe: Recipe) {
        var recipes = getAllRecipes()
        recipes.append(recipe)
        saveRecipes(recipes)
    }
    
    func getAllRecipes() -> [Recipe] {
        guard let data = UserDefaults.standard.data(forKey: userDefaultsKey) else {
            return []
        }
        do {
            let recipes = try JSONDecoder().decode([Recipe].self, from: data)
            return recipes
        } catch {
            print("Error decoding recipes: \(error.localizedDescription)")
            return []
        }
    }
    
    func updateRecipe(_ updatedRecipe: Recipe) {
        var recipes = getAllRecipes()
        if let index = recipes.firstIndex(where: { $0.id == updatedRecipe.id }) {
            recipes[index] = updatedRecipe
            saveRecipes(recipes)
        }
    }
    
    func deleteRecipe(withID id: String) {
        var recipes = getAllRecipes()
        recipes.removeAll(where: { $0.id == id })
        saveRecipes(recipes)
    }
    
    // MARK: - Helper methods
    
    func sampleRecipes() {
        guard let url = Bundle.main.url(forResource: "SampleRecipes", withExtension: "plist") else {
            fatalError("Invalid URL")
        }
        
        do {
            let data = try Data(contentsOf: url)
            let sampleRecipeData = try PropertyListSerialization.propertyList(from: data, options: [], format: nil) as! [[String : String]]
            var recipeList = [Recipe]()
            for recipe in sampleRecipeData {
                guard let img = UIImage(named: recipe["Type"]!) else { return }
                var imageData: Data?
                guard let data = img.jpegData (compressionQuality: 0.5) else { return }
                imageData = try! PropertyListEncoder ().encode (data)
                
                let sampleRecipe = Recipe(type: recipe["Type"]!, name: recipe["Name"]!, image: imageData!, description: recipe["Description"]!, ingredients: recipe["Ingredients"]!, steps: recipe["Steps"]!)
                recipeList.append(sampleRecipe)
                
            }
            saveRecipes(recipeList)
        } catch {
            fatalError("Could not load plist as [[String : Any]]")
        }
    }
    
    private func saveRecipes(_ recipes: [Recipe]) {
        do {
            let data = try JSONEncoder().encode(recipes)
            UserDefaults.standard.set(data, forKey: userDefaultsKey)
        } catch {
            print("Error encoding recipes: \(error.localizedDescription)")
        }
    }
    
}
