//
//  RecipeDetailViewController.swift
//  Recipe App
//
//  Created by Rayan on 30/06/2024.
//

import UIKit

class RecipeDetailViewController: UIViewController {
    
    // MARK: IB Outlets
    @IBOutlet weak var recipeNameLbl: UILabel!
    @IBOutlet weak var recipeIV: UIImageView!
    @IBOutlet weak var recipeTypeLbl: UILabel!
    @IBOutlet weak var recipeDescriptionLbl: UILabel!
    @IBOutlet weak var recipeIngredientsLbl: UILabel!
    @IBOutlet weak var recipeStepsLbl: UILabel!
    
    // MARK: - Properties
    var recipe: Recipe!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        initUI()
    }
    
    func initUI() {
        title = "Recipe Detail"
        recipeNameLbl.text = recipe.name
        let decoded = try! PropertyListDecoder().decode(Data.self, from: recipe.image ?? Data())
        let image = UIImage(data: decoded)
        recipeIV.image = image
        recipeTypeLbl.text = recipe.type
        recipeDescriptionLbl.text = recipe.description
        recipeIngredientsLbl.text = recipe.ingredients
        recipeStepsLbl.text = recipe.steps
    }
    
    // MARK: - IB Actions
    @IBAction func editBtnTapped(_ sender: Any) {
        let addEditVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "AddEditVC") as! AddEditRecipeViewController
        addEditVC.recipe = self.recipe
        navigationController?.pushViewController(addEditVC, animated: true)
    }
    
}
