//
//  MainViewController.swift
//  Recipe App
//
//  Created by Rayan on 29/06/2024.
//

import UIKit

class MainViewController: UIViewController {
    
    // MARK: - IB Outlets
    @IBOutlet weak var recipeTV: UITableView!
    @IBOutlet weak var recipeTypePV: UIPickerView!
    @IBOutlet weak var pickerViewTB: UIToolbar!
    
    // MARK: - Properties
    var recipeTypeData: [[String : String]] = []
    var recipeList: [Recipe]?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        recipeTypePV.dataSource = self
        recipeTypePV.delegate = self
        recipeTV.dataSource = self
        recipeTV.delegate = self
        getRecipeTypes()
        getRecipes()
        
        NotificationCenter.default.addObserver(self, selector: #selector(getRecipes), name: NSNotification.Name ("RefreshRecipeList"), object: nil)
    }
    
    func getRecipeTypes() {
        guard let url = Bundle.main.url(forResource: "RecipeTypes", withExtension: "plist") else {
            fatalError("Invalid URL")
        }
        do {
            let data = try Data(contentsOf: url)
            recipeTypeData = try PropertyListSerialization.propertyList(from: data, options: [], format: nil) as! [[String : String]]
        } catch {
            fatalError("Could not load plist as [[String : Any]]")
        }
    }
    
    @objc func getRecipes() {
        if DataManager().getAllRecipes().isEmpty {
            DataManager().sampleRecipes()
        }
        recipeList = DataManager().getAllRecipes()
        recipeTV.reloadData()
    }
    
    func filterRecipeList(_ filterSelected: String) {
        recipeList = DataManager().getAllRecipes().filter({ $0.type == filterSelected})
        recipeTV.reloadData()
    }
    
    // MARK: - IB Actions
    
    @IBAction func filterBtnTapped(_ sender: Any) {
        recipeTypePV.isHidden = false
        pickerViewTB.isHidden = false
    }
    
    @IBAction func addBtnTapped(_ sender: Any) {
        let addEditVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "AddEditVC") as! AddEditRecipeViewController
        navigationController?.pushViewController(addEditVC, animated: true)
    }
    
    @IBAction func doneBtnTapped(_ sender: Any) {
        recipeTypePV.isHidden = true
        pickerViewTB.isHidden = true
    }
    
}

extension MainViewController: UIPickerViewDataSource, UIPickerViewDelegate {
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        recipeTypeData.count + 1
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if row == 0 {
            return "All"
        }
        else {
            let d = recipeTypeData[row - 1]
            return d["Name"] ?? "Not Available"
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if row == 0 {
            getRecipes()
        }
        else {
            filterRecipeList(recipeTypeData[row - 1]["Name"]!)
        }
    }
    
}

extension MainViewController: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        recipeList?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "RecipeTVCell", for: indexPath) as! RecipeTableViewCell
        cell.setData(recipeList![indexPath.row])
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let recipeDetailVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "RecipeDetailVC") as! RecipeDetailViewController
        recipeDetailVC.recipe = recipeList![indexPath.row]
        navigationController?.pushViewController(recipeDetailVC, animated: true)
        tableView.deselectRow(at: indexPath, animated: true)
    }
    
}

