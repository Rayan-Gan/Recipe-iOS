//
//  AddEditRecipeViewController.swift
//  Recipe App
//
//  Created by Rayan on 30/06/2024.
//

import UIKit

class AddEditRecipeViewController: UIViewController {
    
    // MARK: - IB Outlets
    @IBOutlet weak var recipeIV: UIImageView!
    @IBOutlet weak var recipeImgLbl: UILabel!
    @IBOutlet weak var recipeNameTF: UITextField!
    @IBOutlet weak var recipeTypeTF: UITextField!
    @IBOutlet weak var recipeTypePV: UIPickerView!
    @IBOutlet weak var recipeDescriptionTV: UITextView!
    @IBOutlet weak var recipeIngredientsTV: UITextView!
    @IBOutlet weak var recipeStepsTV: UITextView!
    @IBOutlet weak var deleteBtn: UIButton!
    
    // MARK: - Properties
    var recipe: Recipe?
    var imagePicker = UIImagePickerController()
    var plistData: [[String : String]] = []
    let placeholderColour = UIColor(red: 0.85, green: 0.85, blue: 0.85, alpha: 1.0)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        initUI()
        getRecipeTypes()
        
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow), name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide), name: UIResponder.keyboardWillHideNotification, object: nil)
    }
    
    func initUI() {
        if recipe != nil {
            title = "Edit Recipe"
            let decoded = try! PropertyListDecoder().decode(Data.self, from: recipe!.image!)
            let image = UIImage(data: decoded)
            recipeIV.image = image
            recipeImgLbl.text = "Tap to change photo"
            recipeNameTF.text = recipe!.name
            recipeTypeTF.text = recipe!.type
            recipeDescriptionTV.text = recipe!.description
            recipeIngredientsTV.text = recipe!.ingredients
            recipeStepsTV.text = recipe!.steps
        }
        else {
            title = "Add Recipe"
            recipeDescriptionTV.textColor = placeholderColour
            recipeIngredientsTV.textColor = placeholderColour
            recipeStepsTV.textColor = placeholderColour
            deleteBtn.isHidden = true
        }
        recipeTypePV.dataSource = self
        recipeTypePV.delegate = self
        
        recipeTypeTF.delegate = self
        recipeTypeTF.inputView = recipeTypePV
        
        recipeDescriptionTV.delegate = self
        recipeIngredientsTV.delegate = self
        recipeStepsTV.delegate = self
        
        setTextViewBorder([recipeDescriptionTV, recipeIngredientsTV, recipeStepsTV])
    }
    
    func getRecipeTypes() {
        guard let url = Bundle.main.url(forResource: "RecipeTypes", withExtension: "plist") else {
            fatalError("Invalid URL")
        }
        
        do {
            let data = try Data(contentsOf: url)
            plistData = try PropertyListSerialization.propertyList(from: data, options: [], format: nil) as! [[String : String]]
            print(plistData)
        } catch {
            fatalError("Could not load plist as [[String : Any]]")
        }
    }
    
    func setTextViewBorder(_ textViews: [UITextView]) {
        for textView in textViews {
            textView.layer.borderColor = placeholderColour.cgColor
            textView.layer.borderWidth = 0.5
            textView.layer.cornerRadius = 5
            textView.layer.masksToBounds = true
        }
    }
    
    @objc func keyboardWillShow(notification: NSNotification) {
        if !recipeNameTF.isFirstResponder {
            if let keyboardSize = (notification.userInfo?[UIResponder.keyboardFrameBeginUserInfoKey] as? NSValue)?.cgRectValue {
                if self.view.frame.origin.y == 0 {
                    self.view.frame.origin.y -= keyboardSize.height
                }
            }
            
        }
    }
    
    @objc func keyboardWillHide(notification: NSNotification) {
        if !recipeNameTF.isFirstResponder  {
            if self.view.frame.origin.y != 0 {
                self.view.frame.origin.y = 0
            }
        }
    }
    
    // MARK: - IB Actions
    @IBAction func recipeIVTapped(_ sender: Any) {
        if UIImagePickerController.isSourceTypeAvailable(.savedPhotosAlbum){
            print("Button capture")
            
            imagePicker.delegate = self
            imagePicker.sourceType = .savedPhotosAlbum
            imagePicker.allowsEditing = false
            
            present(imagePicker, animated: true, completion: nil)
        }
    }
    
    @IBAction func deleteBtnTapped(_ sender: Any) {
        DataManager().deleteRecipe(withID: recipe!.id!)
        self.navigationController?.popToRootViewController(animated: true)
    }
    
    @IBAction func saveBtnTapped(_ sender: Any) {
        var imageData: Data?
        guard let image = recipeIV.image, let data = image.jpegData (compressionQuality: 0.5) else { return }
        imageData = try! PropertyListEncoder ().encode (data)
        if recipe != nil {
            recipe!.update(type: recipeTypeTF.text!, name: recipeNameTF.text!, image: imageData ?? Data(), description: recipeDescriptionTV.text, ingredients: recipeIngredientsTV.text, steps: recipeStepsTV.text)
            DataManager().updateRecipe(recipe!)
        }
        else {
            let newRecipe = Recipe(type: recipeTypeTF.text!, name: recipeNameTF.text!, image: imageData ?? Data(), description: recipeDescriptionTV.text, ingredients: recipeIngredientsTV.text, steps: recipeStepsTV.text)
            DataManager().addRecipe(newRecipe)
        }
        NotificationCenter.default.post(name: NSNotification.Name("RefreshRecipeList"), object: nil)
        self.navigationController?.popToRootViewController(animated: true)
    }
    
}

extension AddEditRecipeViewController: UINavigationControllerDelegate, UIImagePickerControllerDelegate {
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        picker.dismiss(animated: true, completion: nil)
        guard let image = info[.originalImage] as? UIImage else {
            fatalError("Expected a dictionary containing an image, but was provided the following: \(info)")
        }
        self.recipeIV.image = image
    }
    
}

extension AddEditRecipeViewController: UITextFieldDelegate {
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        if textField == recipeTypeTF {
            recipeTypePV.isHidden = false
            return false
        }
        else {
            return true
        }
    }
    
}

extension AddEditRecipeViewController: UIPickerViewDataSource, UIPickerViewDelegate {
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return plistData.count
    }
    
    func pickerView( _ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        let d = plistData[row]
        return d["Name"] ?? "Not Available"
    }
    
    func pickerView( _ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        recipeTypeTF.text = plistData[row]["Name"]
        pickerView.isHidden = true
    }
    
}

extension AddEditRecipeViewController: UITextViewDelegate {
    
    func textViewDidBeginEditing(_ textView: UITextView) {
        if textView.textColor == placeholderColour {
            textView.text = ""
            textView.textColor = UIColor.black
        }
    }
    
    func textViewDidEndEditing(_ textView: UITextView) {
        if textView.text == "" {
            textView.text = textView == recipeDescriptionTV ? "Enter a description" : textView == recipeIngredientsTV ? "Enter ingredients" : "Enter steps"
            textView.textColor = placeholderColour
        }
    }
    
}
