//
//  RecipeTableViewCell.swift
//  Recipe App
//
//  Created by Rayan on 30/06/2024.
//

import UIKit

class RecipeTableViewCell: UITableViewCell {
    
    // MARK: - IB Outlets
    @IBOutlet weak var recipeIV: UIImageView!
    @IBOutlet weak var recipeNameLbl: UILabel!
    @IBOutlet weak var recipeDescriptionLbl: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    func setData(_ recipe: Recipe) {
        let decoded = try! PropertyListDecoder().decode(Data.self, from: recipe.image ?? Data())
        let image = UIImage(data: decoded)
        recipeIV.image = image
        recipeNameLbl.text = recipe.name
        recipeDescriptionLbl.text = recipe.description
    }
    
}
